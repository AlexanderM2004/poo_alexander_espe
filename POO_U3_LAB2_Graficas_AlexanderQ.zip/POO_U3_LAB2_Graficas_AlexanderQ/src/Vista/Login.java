package Vista;

import Conexion.Conexion;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import static java.awt.image.ImageObserver.HEIGHT;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Alexander Quizhpe
 */
public class Login extends javax.swing.JFrame {
    
    Conexion frm = new Conexion();
    Connection con = frm.Conectar();
    
    //Creacion del panel
    public JPanel panel;
    
    JTextField txt_Usser = new JTextField();
    JPasswordField txt_Pass = new JPasswordField();
    
    //Creamos una ventana grafica con JFrame
    public Login (){
       this.setSize(400,400); 
       setTitle("Iniciar Sesion"); //Comando que permitecolocar nombre a la ventana
       //Comando que permite finalizar todo el programa en el momento que se cierra la ventana
       setDefaultCloseOperation(EXIT_ON_CLOSE);
       //Comando para centrar la ventana del monitor
       setLocationRelativeTo(null);
       iniciarComponentes();
    }
    
    private void iniciarComponentes(){
        colocarPanel();
        colocarEtiquetas();
        ColocarBotones();
        ColocarCajatexto();
    }
    
    private void colocarPanel(){
        panel = new JPanel();
        //Comando para aplicar color al panel
        panel.setBackground(Color.white);
        //Poner el panel sobre la ventana del registro
        this.getContentPane().add(panel);
    }
    
    public void colocarEtiquetas(){
        JLabel label = new JLabel("LOGIN",SwingConstants.CENTER);
        panel.add(label);
        panel.setLayout(null);
        label.setBounds(150, 30, 100, 20);
        label.setFont(new Font("Arial", Font.PLAIN, 20));
        label.setForeground(Color.BLACK);
        
        JLabel label1 = new JLabel();
        label1.setText("Usser: ");
        panel.add(label1);
        //Comando para ubicar el label
        label1.setHorizontalAlignment(HEIGHT);
        //comando para modificar fuente de letra
        label1.setFont(new Font("Arial", Font.PLAIN, 15));
        label1.setBounds(35, 220, 80, 15);
        
        JLabel label2 = new JLabel();
        label2.setText("Password: ");
        panel.add(label2);
        //Comando para ubicar el label
        label2.setHorizontalAlignment(HEIGHT);
        //comando para modificar fuente de letra
        label2.setFont(new Font("Arial", Font.PLAIN, 15));
        label2.setBounds(35, 260, 80, 15);
        
        //Comando para colocar imagen
        JLabel labelimagen = new JLabel();
        ImageIcon imagen = new ImageIcon("usser.png");//La imagen se encuetra en la misma carpeta del proyecto
        labelimagen.setBounds(135, 70, 130, 130);
        panel.add(labelimagen);
        //Modificar imagen
        labelimagen.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(labelimagen.getWidth(), labelimagen.getHeight(), Image.SCALE_SMOOTH)));
    }
    
    //Comando para colocar cajas de texto
    public void ColocarCajatexto(){
        
        txt_Usser.setBounds(120, 217, 200, 20);
        panel.add(txt_Usser);
        
        txt_Pass.setBounds(120, 257, 200, 20);
        panel.add(txt_Pass);
        
    }
    
    public void ColocarBotones(){
        JButton Iniciar = new JButton("Iniciar Sesion");
        Iniciar.setBounds(125, 300, 150, 30);
        panel.add(Iniciar);
        Iniciar.setEnabled(true);//Sirve para habilitar o deshabilitar los botones
    }
    
    public void validarUsuario(){
        int resultado = 0 ;
        String usu_pass = String.valueOf(txt_Pass.getPassword());
        String usu_usuario = txt_Usser.getText();
        String SQL = "select *from usuario where usu_usuario = '"+usu_usuario+"' and usu_pass = '"+usu_pass+"'";
        
        try{
           Statement st = (Statement) con.createStatement(); 
           ResultSet rs = st.executeQuery(SQL);
           if(rs.next()){
               resultado = 1;
               if(resultado == 1){
                Formulario inicio = new Formulario();  
                inicio.setVisible(true);
                this.dispose();
                JOptionPane.showMessageDialog(null, "Bienvenido de nuevo " + usu_usuario);
               }
           }else{
               JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrecta, vuelva a intentarlo");
           }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error de Login, " + e);
        }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    } 
}
