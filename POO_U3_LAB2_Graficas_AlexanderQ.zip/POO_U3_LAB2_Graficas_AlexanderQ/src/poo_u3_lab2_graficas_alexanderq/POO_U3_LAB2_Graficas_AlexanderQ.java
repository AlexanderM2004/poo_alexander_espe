package poo_u3_lab2_graficas_alexanderq;

import Vista.Formulario;
import Vista.Formulario_Horario;
import Vista.Formulario_Profesor;
import Vista.Login;
import Vista.Registrar;

/**
 *
 * @author Alexander Quizhpe
 */

public class POO_U3_LAB2_Graficas_AlexanderQ {
    public static void main(String[] args) {
        // TODO code application logic here
        //Formulario form = new Formulario();
        //form.setVisible(true);
        
        Formulario_Horario form_hora = new Formulario_Horario();
        form_hora.setVisible(true);
        
        //Formulario_Profesor form_profe = new Formulario_Profesor();
        //form_profe.setVisible(true);
        
        //Login log = new Login();
        //log.setVisible(true);
        
        //Registrar iniciar = new Registrar();
        //iniciar.setVisible(true);
    }
    
}
